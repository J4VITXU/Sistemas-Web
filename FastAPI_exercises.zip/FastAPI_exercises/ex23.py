from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

app = FastAPI()

# ----------------------------
# 1. Montar directorio /static
# ----------------------------
app.mount("/static", StaticFiles(directory="static"), name="static")


# ----------------------------
# API de ejemplo para usarla desde index.html
# ----------------------------
fake_users = [
    {"id": 1, "name": "Carmen"},
    {"id": 2, "name": "Luis"},
]

@app.get("/users")
def list_users():
    return fake_users
