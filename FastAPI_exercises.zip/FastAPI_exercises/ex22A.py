from typing import Optional, List
from fastapi import FastAPI, Depends, HTTPException, status
from sqlmodel import SQLModel, Field, Session, create_engine, select

# ---------- Modelos (SQLModel) ----------
class HeroBase(SQLModel):
    name: str
    age: Optional[int] = None
    secret_name: str

class Hero(HeroBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)

# Modelos de E/S (como en el tutorial: separar entrada/salida)
class HeroCreate(HeroBase):
    pass

class HeroRead(SQLModel):
    id: int
    name: str
    age: Optional[int] = None

class HeroUpdate(SQLModel):
    name: Optional[str] = None
    age: Optional[int] = None
    secret_name: Optional[str] = None

# ---------- DB / Engine / Session ----------
sqlite_url = "sqlite:///./heroes.db"
engine = create_engine(sqlite_url, echo=False)  # echo=True si quieres ver SQL

def create_db_and_tables():
    SQLModel.metadata.create_all(engine)

def get_session():
    with Session(engine) as session:
        yield session

app = FastAPI(on_startup=[create_db_and_tables])

# ---------- CRUD ----------
# POST /heroes/ — create
@app.post("/heroes/", response_model=HeroRead, status_code=status.HTTP_201_CREATED)
def create_hero(hero_in: HeroCreate, session: Session = Depends(get_session)):
    hero = Hero.model_validate(hero_in)  # convierte a tabla
    session.add(hero)
    session.commit()
    session.refresh(hero)
    return HeroRead.model_validate(hero)  # no filtramos manual: mapeamos al modelo de salida

# GET /heroes/{hero_id} — read by id
@app.get("/heroes/{hero_id}", response_model=HeroRead)
def read_hero(hero_id: int, session: Session = Depends(get_session)):
    hero = session.get(Hero, hero_id)
    if not hero:
        raise HTTPException(status_code=404, detail="Hero not found")
    return HeroRead.model_validate(hero)

# GET /heroes/ — list
@app.get("/heroes/", response_model=List[HeroRead])
def list_heroes(session: Session = Depends(get_session)):
    heroes = session.exec(select(Hero)).all()
    return [HeroRead.model_validate(h) for h in heroes]

# PUT /heroes/{hero_id} — update (reemplazo completo)
@app.put("/heroes/{hero_id}", response_model=HeroRead)
def update_hero(hero_id: int, data: HeroBase, session: Session = Depends(get_session)):
    hero = session.get(Hero, hero_id)
    if not hero:
        raise HTTPException(status_code=404, detail="Hero not found")
    # reemplazo total (como en el tutorial)
    hero.name = data.name
    hero.age = data.age
    hero.secret_name = data.secret_name
    session.add(hero)
    session.commit()
    session.refresh(hero)
    return HeroRead.model_validate(hero)

# DELETE /heroes/{hero_id} — delete
@app.delete("/heroes/{hero_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_hero(hero_id: int, session: Session = Depends(get_session)):
    hero = session.get(Hero, hero_id)
    if not hero:
        raise HTTPException(status_code=404, detail="Hero not found")
    session.delete(hero)
    session.commit()
    return None
